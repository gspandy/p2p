cslc_shorturl
id:Long,code:String,url:String,createtime:Date

<sqlMap resource="com/cslc/dao/shorturl/Shorturl.xml" />

CREATE TABLE `shorturl` (
  `createtime` datetime default NULL,
  `code` varchar(20) default NULL,
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `url` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;