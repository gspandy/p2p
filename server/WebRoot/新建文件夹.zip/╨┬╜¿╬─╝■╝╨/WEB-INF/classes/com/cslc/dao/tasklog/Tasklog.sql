cslc_tasklog
id:Long,accountid:Long,taskid:Long,createtime:Date,score:Integer

<sqlMap resource="com/cslc/dao/tasklog/Tasklog.xml" />

CREATE TABLE `tasklog` (
  `accountid` bigint(40) default NULL,
  `score` int(10) default NULL,
  `createtime` datetime default NULL,
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `taskid` bigint(40) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;