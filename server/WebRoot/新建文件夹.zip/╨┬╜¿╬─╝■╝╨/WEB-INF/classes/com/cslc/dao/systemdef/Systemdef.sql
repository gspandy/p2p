cslc_systemdef
key:String,val:String,category:String,status:Byte

<sqlMap resource="com/cslc/dao/systemdef/Systemdef.xml" />

CREATE TABLE `systemdef` (
  `v` varchar(20) default NULL,
  `category` varchar(20) default NULL,
  `k` varchar(20) default NULL,
  `status` tinyint(2) default NULL
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;