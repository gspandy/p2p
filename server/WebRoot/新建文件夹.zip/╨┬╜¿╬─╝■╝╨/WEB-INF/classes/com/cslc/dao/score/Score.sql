cslc_score
id:Long,accountid:Long,rewardid:Long,inouttype:Byte,title:String,createtime:Date,usetime:Date,score:Integer,status:Byte,channel:Integer

<sqlMap resource="com/cslc/dao/score/Score.xml" />

CREATE TABLE `score` (
  `accountid` bigint(40) default NULL,
  `score` int(10) default NULL,
  `rewardid` bigint(40) default NULL,
  `createtime` datetime default NULL,
  `inouttype` tinyint(2) default NULL,
  `category` int(10) default NULL,
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) default NULL,
  `usetime` datetime default NULL,
  `status` tinyint(2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;