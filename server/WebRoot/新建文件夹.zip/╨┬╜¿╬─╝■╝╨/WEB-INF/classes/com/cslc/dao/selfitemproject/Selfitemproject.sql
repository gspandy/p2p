cslc_selfitemproject
id:Long,json:String,title:String,agreementid:Long

<sqlMap resource="com/cslc/dao/selfitemproject/Selfitemproject.xml" />

CREATE TABLE `selfitemproject` (
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) default NULL,
  `json` varchar(20) default NULL,
  `selfitemagreementid` bigint(40) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;