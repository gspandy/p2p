cslc_accountbankcard
id:Long,accountid:Long,bankid:Long,bankcardno:String,province:String,city:String,branchname:String,status:Byte,channel:Byte,isdefault:Byte,createtime:Date

<sqlMap resource="com/cslc/dao/accountbankcard/Accountbankcard.xml" />

CREATE TABLE `accountbankcard` (
  `accountid` bigint(40) default NULL,
  `bankid` bigint(40) default NULL,
  `createtime` datetime default NULL,
  `province` varchar(20) default NULL,
  `city` varchar(20) default NULL,
  `channel` tinyint(2) default NULL,
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `isdefault` tinyint(2) default NULL,
  `bankcardno` varchar(20) default NULL,
  `branchname` varchar(20) default NULL,
  `status` tinyint(2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;