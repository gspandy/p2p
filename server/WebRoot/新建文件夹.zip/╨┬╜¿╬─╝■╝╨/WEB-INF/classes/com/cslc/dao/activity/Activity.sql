cslc_activity
id:Long,category:Integer,title:String,createtime:Date,starttime:Date,endtime:Date,status:Byte,share:String

<sqlMap resource="com/cslc/dao/activity/Activity.xml" />

CREATE TABLE `activity` (
  `createtime` datetime default NULL,
  `endtime` datetime default NULL,
  `share` varchar(20) default NULL,
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `starttime` datetime default NULL,
  `category` int(10) default NULL,
  `title` varchar(20) default NULL,
  `status` tinyint(2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;