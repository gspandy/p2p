cslc_analysedayaccount
createtime:Date,accountid:Long,selfitemtodayincome:Double,selfitemtotalincome:Double,selfitemasset:Double,bonusasset:Double,scoreasset:Integer

<sqlMap resource="com/cslc/dao/analysedayaccount/Analysedayaccount.xml" />

CREATE TABLE `analysedayaccount` (
  `createtime` datetime default NULL,
  `bonusasset` decimal(16,2) default NULL,
  `selfitemtodayincome` decimal(16,2) default NULL,
  `selfitemtotalincome` decimal(16,2) default NULL,
  `scoreasset` int(10) default NULL,
  `selfitemasset` decimal(16,2) default NULL,
  `accountid` bigint(40) default NULL
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;