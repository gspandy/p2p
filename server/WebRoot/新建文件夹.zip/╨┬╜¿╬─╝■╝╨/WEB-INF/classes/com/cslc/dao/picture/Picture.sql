cslc_picture
id:Long,manager:String,channel:String,url:String,content:String,status:Byte,createtime:Date

<sqlMap resource="com/cslc/dao/picture/Picture.xml" />

CREATE TABLE `picture` (
  `createtime` datetime default NULL,
  `manager` varchar(20) default NULL,
  `id` bigint(40) NOT NULL AUTO_INCREMENT,
  `channel` varchar(20) default NULL,
  `url` varchar(20) default NULL,
  `content` varchar(20) default NULL,
  `status` tinyint(2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000000000001 DEFAULT CHARSET=utf8;